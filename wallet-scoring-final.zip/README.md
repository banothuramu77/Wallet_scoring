
# 💼 Wallet Credit Scoring — Aave V2

## 🔥 Problem Statement

Assign a robust credit score (0–1000) to DeFi wallets interacting with Aave V2 protocol, based on historical behavior.

## ⚙️ Approach

### Engineered Features

- **Repay ratio**: Measures repayments vs. borrowings.
- **Deposit-to-borrow ratio**: Indicates leverage behavior.
- **Liquidation count**: Penalizes risky wallets.
- **Active longevity**: Days between first and last transaction.
- **Transaction frequency**: Number of transactions.

### Scoring

- Normalize each feature to [0, 1].
- Weighted combination:
  - Repay ratio: 30%
  - Deposit-to-borrow: 20%
  - Liquidations penalty: 30%
  - Longevity: 10%
  - Frequency: 10%
- Final score = weighted sum × 1000.

## 💻 How to Run

```
pip install -r requirements.txt
python wallet_scoring.py
```

## 📄 Outputs

- `wallet_scores.csv`
- `score_distribution.png`
